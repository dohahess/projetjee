package com.example.CentreD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CentreDApplication {

    public static void main(String[] args) {
        SpringApplication.run(CentreDApplication.class, args);
    }
}

	
