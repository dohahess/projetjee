package com.example.CentreD.entities;

public class Secretaire {
    
}
