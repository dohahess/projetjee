package com.example.CentreD.enums;

public enum Mutuelle {
    CNAM,CIMR,CNOPS,CNSS
}
