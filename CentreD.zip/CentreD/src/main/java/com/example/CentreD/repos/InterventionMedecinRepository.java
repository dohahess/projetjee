package com.example.CentreD.repos;

import com.example.CentreD.entities.InterventionMedecin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterventionMedecinRepository extends JpaRepository<InterventionMedecin,Long> {

}
