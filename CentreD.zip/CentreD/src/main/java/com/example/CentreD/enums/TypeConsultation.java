package com.example.CentreD.enums;

public enum TypeConsultation {
    CONSULTATION_GENERALE, SUIVI , URGENCE
}
