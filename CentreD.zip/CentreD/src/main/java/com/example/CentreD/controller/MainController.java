package com.example.CentreD.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.CentreD.entities.Acte;
import com.example.CentreD.entities.Consultation;

import com.example.CentreD.entities.DossierMedical;
import com.example.CentreD.entities.Facture;
import com.example.CentreD.entities.InterventionMedecin;
import com.example.CentreD.entities.Patient;
import com.example.CentreD.entities.Personne;
import com.example.CentreD.entities.SituationFinanciere;
import com.example.CentreD.entities.Utilisateur;
import com.example.CentreD.enums.CategorieActe;

import com.example.CentreD.enums.TypeConsultation;
import com.example.CentreD.repos.ActeRepository;
import com.example.CentreD.repos.ConsultationRepository;
import com.example.CentreD.repos.DossierMedicalRepository;
import com.example.CentreD.repos.FactureRepository;
import com.example.CentreD.repos.InterventionMedecinRepository;
import com.example.CentreD.repos.PatientRepository;
import com.example.CentreD.repos.PersonneRepository;
import com.example.CentreD.repos.SituationFinancierRepository;
import com.example.CentreD.repos.UtilisateurRepository;
import com.example.CentreD.service.servicesDeclaration.PatientService;

import jakarta.transaction.Transactional;

@Controller
@SessionAttributes("user")
public class MainController {
    
    @Autowired
    UtilisateurRepository utilisateurRepository;

    @Autowired
    PatientRepository patientRepository;

    @Autowired 
    DossierMedicalRepository dossierMedicalRepository;

    @Autowired
    SituationFinancierRepository situationFinancierRepository;

    @Autowired
    PatientService patientService;

    @Autowired 
    ConsultationRepository consultationRepository;

    @Autowired
    PersonneRepository personneRepository;

    @Autowired
    ActeRepository acteRepository;

    @Autowired
    InterventionMedecinRepository interventionMedecinRepository;

    @Autowired
    FactureRepository factureRepository;

    @GetMapping("/profile")
    public String profile(@ModelAttribute("user") Utilisateur user,Model model){
        
        model.addAttribute("user", utilisateurRepository.findByEmail(user.getEmail()));
        return "profile";
    }


    @GetMapping("/modiferProfile")
    public String modifierProfile(@ModelAttribute("user") Utilisateur user,Model model){
        model.addAttribute("user", user);
        return "modifierProfile";
    }
    
    @GetMapping("/patients")
    public String listPatients(@ModelAttribute("user") Utilisateur user,Model model){
        model.addAttribute("user", user);
        model.addAttribute("patients", patientService.getDentistPatients(user.getId()));
        return "patients";
    }
    
    @GetMapping("/ajouterPatient")
    public String ajouterPatient(@ModelAttribute("user") Utilisateur user,Model model){
        model.addAttribute("user", user);
        model.addAttribute("patients",   model.addAttribute("patients", patientService.getDentistPatients(user.getId())));
        return "ajouterPatient";
    }

    @PostMapping("/patients")
    public String patientForm(@ModelAttribute("user") Utilisateur user,  @RequestParam("nom") String nom,
            @RequestParam("prenom") String prenom,
            @RequestParam("dateNaissance") String dateNaissance,
            @RequestParam("sexe") String sexe,
            @RequestParam("mutuelle") String mutuelle,
            @RequestParam("groupeSanguin") String groupeSanguin,
            @RequestParam("profession") String profession,
            Model model){
            
           patientService.addPatient(user, nom, prenom, dateNaissance, sexe, mutuelle, groupeSanguin, profession);
                
            model.addAttribute("patients", patientService.getDentistPatients(user.getId()));
            model.addAttribute("user", user);
            return "patients";
    }
    
    @PostMapping("/enregisterProfile")
    @Transactional
    public String redirectToProfile(@ModelAttribute("user") Utilisateur user,Model model){
        utilisateurRepository.save(user);
        model.addAttribute("user", user);
        return "profile";
    }
    
    @GetMapping("/dossierMD/{id}")
    @Transactional
    public String dossierMedical(@ModelAttribute("user") Utilisateur user,@PathVariable("id") Long patientId,Model model){
        
        Utilisateur oldUser = utilisateurRepository.findByEmail(user.getEmail());
        model.addAttribute("user", oldUser);
        model.addAttribute("id", patientId);
        List<DossierMedical> listDossierMedical = dossierMedicalRepository.findByMedecinTraitantId(oldUser.getId());
        DossierMedical dossierMedical2 = listDossierMedical.stream().filter(d -> d.getPatient().getId() == patientId).toList().get(0);
        model.addAttribute("dossier", dossierMedical2);
        
        return "dossierMD";
    }
    
    
    @GetMapping("/consultation/{id}")
    public String consultation(@ModelAttribute("user")Utilisateur user ,@PathVariable("id") Long id ,Model model){
        
        
        Utilisateur oldUser = utilisateurRepository.findByEmail(user.getEmail());
        Patient patient = patientRepository.findAll().stream().filter(p -> p.getId() == id).toList().get(0);
        
        
        List<Consultation> consultations = consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList();
        model.addAttribute("patient", patient);
        model.addAttribute("user", oldUser);
        model.addAttribute("consultations", consultations);

        return "consultation";
    }
    
    @PostMapping("/addConsultation/{id}")
    public String addConsultation(@ModelAttribute("user") Utilisateur user,@PathVariable("id") Long id
    ,@RequestParam("acte") String acte
    ,@RequestParam("prixBase") String prixBase
    ,@RequestParam("date") String date
    ,@RequestParam("nbDents") String nbDents
    ,@RequestParam("prixPatient") String prixPatient
    ,Model model
    ){
        
        Utilisateur oldUser = utilisateurRepository.findByEmail(user.getEmail());
        Patient patient     = patientRepository.findById(id).orElse(null);
        DossierMedical  dossierMedical  = dossierMedicalRepository.findByMedecinTraitantId(oldUser.getId()).stream().filter(d -> d.getPatient().getId() == patient.getId()).toList().get(0);
        
        
        Consultation consultation = new Consultation();
        
        String[] parses = date.split("-");
        
        consultation.setDateConsultation(LocalDate.of(Integer.parseInt(parses[0]), Integer.parseInt(parses[1]), Integer.parseInt(parses[2]))
        );
        consultation.setTypeConsultation(TypeConsultation.CONSULTATION_GENERALE);
        consultation.setDossierMedical(dossierMedical);
        consultation.setInterventions(new ArrayList<>());
        consultation.setFactures(new ArrayList<>());
        consultation = consultationRepository.save(consultation);
        
        Acte acteEntity = acteRepository.findByLibelle(acte);
        if (acteEntity == null){
            acteEntity = new Acte();
            acteEntity.setLibelle(acte);
            acteEntity.setPrixDeBase(Double.parseDouble(prixBase));
            acteEntity.setCategorieActe(CategorieActe.valueOf(acte));
            acteEntity = acteRepository.save(acteEntity);
        }
        InterventionMedecin interventionMedecin = new InterventionMedecin();
        interventionMedecin.setNoteMedecin(acte);
        interventionMedecin.setPrixPatient(Double.parseDouble(prixPatient));
        interventionMedecin.setDent(Long.parseLong(nbDents));
        interventionMedecin.setConsultation(consultation);
        interventionMedecin.setActe(acteEntity);
        interventionMedecin = interventionMedecinRepository.save(interventionMedecin);
        
        
        consultation.getInterventions().add(interventionMedecin);
        dossierMedical.getConsultations().add(consultation);
        dossierMedicalRepository.save(dossierMedical);
        model.addAttribute("user", utilisateurRepository.findByEmail(user.getEmail()));
        model.addAttribute("patient",patient);
        model.addAttribute("consultations", consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList());
        
        return "consultation";
    }
    
    
    @GetMapping("/deletePatient/{id}")
    public String deletePatient(@ModelAttribute("user") Utilisateur user,  @PathVariable("id") Long id , Model model){
        
        
        
        Utilisateur oldUser = utilisateurRepository.findByEmail(user.getEmail());

        
        Patient patient = patientService.getDentistPatients(oldUser.getId()).stream().filter(p -> p.getId() == id).toList().get(0);
        
        Personne personne = personneRepository.findAll().stream().filter(p -> p.getId() == patient.getId()).toList().get(0);
        
        DossierMedical dossierMedical = dossierMedicalRepository.findAll().stream().filter(d -> 
        d.getNumeroDossier()
        .equals(patient.getDossierMedical()
        .getNumeroDossier())).toList().get(0);
        
        List<Consultation> consultations = consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getNumeroDossier().equals(dossierMedical.getNumeroDossier())).toList();

        ArrayList<Long> ids = new ArrayList<>();
        
        for (Consultation c  : consultations)
            ids.add(c.getIdConsultation());


        SituationFinanciere situationFinanciere = situationFinancierRepository.findAll().stream().filter(
            s -> s.getIdSituationFinanciere() == dossierMedical.getSituationFinanciere().getIdSituationFinanciere()
            ).toList().get(0);

        List<Facture> factures = factureRepository.findAll().stream().filter(f -> f.getConsultation().getDossierMedical().getPatient().getId() == patient.getId()).toList();

            List<InterventionMedecin> interventionMedecins = interventionMedecinRepository.findAll().stream().filter(i -> ids.contains(i.getConsultation().getIdConsultation())).toList();

            interventionMedecinRepository.deleteAll();
            factureRepository.deleteAll(factures);
            consultationRepository.deleteAll(consultations);
            dossierMedicalRepository.delete(dossierMedical);
            situationFinancierRepository.delete(situationFinanciere);
            patientRepository.delete(patient);
            personneRepository.delete(personne);
            model.addAttribute("user", oldUser);
            model.addAttribute("patients", patientService.getDentistPatients(oldUser.getId()));
            return "patients";  
            
        }
        
        
        
        @GetMapping("/deleteConsultation/{idc}/{id}")
        public String supprimerConsultation(
            @ModelAttribute("user") Utilisateur user,
            @PathVariable("idc") Long idc,
            @PathVariable("id") Long id,
            Model model
            ){
                
                
                List<InterventionMedecin> interventionMedecin = interventionMedecinRepository.findAll().stream().filter(i -> i.getConsultation().getIdConsultation() == idc).toList();
                
                
                Patient patient = patientRepository.findById(id).orElse(new Patient());
                
                
                interventionMedecinRepository.deleteAll(interventionMedecin);
                consultationRepository.deleteById(idc);
                
                model.addAttribute("user", utilisateurRepository.findByEmail(user.getEmail()));
                model.addAttribute("patient",patient);
                model.addAttribute("consultations", consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList());
                
                
                return "consultation";
            }
            
            
            
            @GetMapping("/situationFinanciere/{id}")
            public String Situation(@ModelAttribute("user") Utilisateur user,@PathVariable("id") Long id,Model model){
                
                
                Utilisateur oldUser = utilisateurRepository.findByEmail(user.getEmail());
                
                Patient patient = patientRepository.findAll().stream().filter(p -> p.getId() == id).toList().get(0);
                
                
                List<Consultation> consultations = consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList();
                
                ArrayList<Long> ids = new ArrayList<>();
                for (Consultation c  : consultations)
                ids.add(c.getIdConsultation());
                
                
                List<Facture> factures = factureRepository.findAll();
                if (factures.size() != 0)
                factures = factures.stream().filter(f -> ids.contains(f.getConsultation().getIdConsultation())).toList();
                
                model.addAttribute("factures", factures);
                model.addAttribute("user", oldUser);
                model.addAttribute("patient", patient);
                return "situationFinanciere";
            }
            
            
            @PostMapping("/addFacture/{id}")
            public String addFacture(@ModelAttribute("user") Utilisateur user,Model model,@PathVariable("id") Long id,
            @RequestParam("idc") String idc,
            @RequestParam("date") String date,
            @RequestParam("etat") String etat,
            @RequestParam("reste") String reste,
            @RequestParam("montant") String montant,
            @RequestParam("totale") String totale
            
            ){
                
                Patient patient = patientRepository.findById(id).orElse(null);
                
                Consultation consultation =  consultationRepository.findById(Long.parseLong(idc)).orElse(null);
                
                Facture facture = new Facture();
                facture.setConsultation(consultation);
                
                String[] parses = date.split("-");
                facture.setDateFacturation(LocalDate.of(Integer.parseInt(parses[0]), Integer.parseInt(parses[1]), Integer.parseInt(parses[2]))
                );
                
                facture.setEtat(etat);
                facture.setMontantRestant(Double.parseDouble(reste));
                facture.setMontantPaye(Double.parseDouble(montant));
                facture.setMontantTotal(Double.parseDouble(totale));
                
                factureRepository.save(facture);
                
                
                List<Consultation> consultations = consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList();
                
                ArrayList<Long> ids = new ArrayList<>();
                for (Consultation c  : consultations)
                ids.add(c.getIdConsultation());
                
                
                List<Facture> factures = factureRepository.findAll();
                if (factures.size() != 0)
                factures = factures.stream().filter(f -> ids.contains(f.getConsultation().getIdConsultation())).toList();
                
                model.addAttribute("user", utilisateurRepository.findByEmail(user.getEmail()));
                model.addAttribute("patient", patient);
                model.addAttribute("factures", factures);
                
                return "situationFinanciere";
                
            }
            
            
            @GetMapping("/deleteFacture/{idf}/{id}")
            public String deleteFacture(@ModelAttribute("user") Utilisateur user,@PathVariable("id") Long id,@PathVariable("idf") Long idf,Model model){
                
                
                Patient patient = patientRepository.findById(id).orElse(null);
                factureRepository.deleteById(idf);
                
                
                List<Consultation> consultations = consultationRepository.findAll().stream().filter(c -> c.getDossierMedical().getPatient().getId() == patient.getId()).toList();
                
                ArrayList<Long> ids = new ArrayList<>();
                for (Consultation c  : consultations)
                ids.add(c.getIdConsultation());
                
                
                List<Facture> factures = factureRepository.findAll();
                if (factures.size() != 0)
                factures = factures.stream().filter(f -> ids.contains(f.getConsultation().getIdConsultation())).toList();
                
                model.addAttribute("user", utilisateurRepository.findByEmail(user.getEmail()));
                model.addAttribute("patient", patient);
                model.addAttribute("factures", factures);
                
                return "situationFinanciere";
            }
            
            
            @GetMapping("/caisse")
            public String caisse(@ModelAttribute("user") Utilisateur user,Model model
            ){
              
                List<Facture> factures = factureRepository.findAll().stream().filter(f -> f.getConsultation().getDossierMedical().getMedecinTraitant().getId() == user.getId()).toList();

                model.addAttribute("user", user);
                model.addAttribute("factures", factures);
             
                return "caisse";
            }

            @GetMapping("/agenda")
            public String agenda(){
                return "agenda";
            }
            

           @GetMapping("/personnel") 
           public String pesronnel(@ModelAttribute("user") Utilisateur user,Model model){
            model.addAttribute("user", user);
            model.addAttribute("personnels", utilisateurRepository.findAll());
            return "personnel";

           }

        }
        