package com.example.CentreD.enums;

public enum StatutPaiement {
    EN_ATTENTE,IMPAYÉ,PAYÉ
}
