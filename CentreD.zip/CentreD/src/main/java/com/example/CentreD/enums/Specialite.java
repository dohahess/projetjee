package com.example.CentreD.enums;

public enum Specialite {
    ENDODONTIE,CHIRURGIE_DENTAIRE,PROTHÈSE, ORTHODONTIE ,PARODONTOLOGIE
    ,AUTRE
}