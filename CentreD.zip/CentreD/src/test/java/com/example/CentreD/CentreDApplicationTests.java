package com.example.CentreD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentreDApplicationTests {

	@Test
	void contextLoads() {
	}

}
