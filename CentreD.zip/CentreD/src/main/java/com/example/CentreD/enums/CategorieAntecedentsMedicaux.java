package com.example.CentreD.enums;

public enum CategorieAntecedentsMedicaux {
    MALADIE_CHRONIQUE, CONTRE_INDICATION,MALADIE_HEREDITAIRE,ALLERGIE
}
