package com.example.CentreD.enums;

public enum TypePaiement {
    CHEQUE, VIREMENT, CARTE_CREDIT, ESPECE , AUTRE
}