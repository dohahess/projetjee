package com.example.CentreD.repos;

import com.example.CentreD.entities.AntecendentMedical;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AntecedantMedRepository extends JpaRepository<AntecendentMedical,Long> {
}
