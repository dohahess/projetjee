package com.example.CentreD.repos;

import com.example.CentreD.entities.SituationFinanciere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SituationFinancierRepository extends JpaRepository<SituationFinanciere,Long> {
}
