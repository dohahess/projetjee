package com.example.CentreD.controller;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.CentreD.entities.Patient;
import com.example.CentreD.entities.Utilisateur;
import com.example.CentreD.repos.PatientRepository;
import com.example.CentreD.service.servicesDeclaration.UtilisateurService;

@Controller
@SessionAttributes("user")
public class login {

    @Autowired
    UtilisateurService utilisateurService;
    @Autowired 
    PatientRepository patientRepository;

    @GetMapping("/")
    public String login(){
        return "login";
    }

    @PostMapping("/register")
    public String register(@RequestParam String email , @RequestParam String password,Model model)
    {

        Utilisateur utilisateur = utilisateurService.checkUtilisateur(email, password);
        model.addAttribute("user", utilisateur);
        if (utilisateur == null)
            return "login";

        List<Patient> patients = patientRepository.findAll().stream().filter(p -> p.getDossierMedical().getMedecinTraitant().getId() == utilisateur.getId()).toList();

        model.addAttribute("patients", patients);

        List<Patient> todayPatients = patients.stream().filter(p -> p.getDossierMedical().getConsultations().size() != 0).filter(p -> p.getDossierMedical().getConsultations().get(0).getDateConsultation().equals(LocalDate.now())).toList();

        model.addAttribute("todayPatients", todayPatients);

        return "home";
    }
    

    




}
