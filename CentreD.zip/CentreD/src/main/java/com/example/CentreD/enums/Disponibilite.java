package com.example.CentreD.enums;

public enum Disponibilite {
    Matin ,Apres_Midi, Toute_La_Journee
}
