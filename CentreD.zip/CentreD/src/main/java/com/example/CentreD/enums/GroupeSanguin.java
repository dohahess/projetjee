package com.example.CentreD.enums;

public enum GroupeSanguin {    
    O_NEGATIF,A_POSITIF , B_NEGATIF ,AB_POSITIF,AB_NEGATIF, A_NEGATIF,O_POSITIF ,B_POSITIF
}
