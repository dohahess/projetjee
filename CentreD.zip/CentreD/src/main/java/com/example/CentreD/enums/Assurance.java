package com.example.CentreD.enums;

public enum Assurance {
    AUTRE,CIMR,CNOPS,CNSS
}
