package com.example.CentreD.enums;

public enum StatusEmploye {
    EN_ARRÊT_MALADIE, AUTRE,EnConge,InActif, Actif
}